// techmates-backend/config/db.js
const mongoose = require('mongoose');

mongoose.connect('mongodb+srv://baggahimal5:Himal1234@techmates.lanky14.mongodb.net/?retryWrites=true&w=majority&appName=TechMates', {
  
})
.then(() => console.log('MongoDB connected'))
.catch(err => console.log(err));