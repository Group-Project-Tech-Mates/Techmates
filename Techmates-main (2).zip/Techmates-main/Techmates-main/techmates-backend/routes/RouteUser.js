const express = require('express');
const router = express.Router();
const { check, validationResult } = require('express-validator');
const userController = require('../controllers/userController'); // Correct path

console.log('Registering routes...');

router.post('/create', (req, res, next) => {
  console.log('POST /create');
  next();
}, userController.createUser);

router.get('/:id', (req, res, next) => {
  console.log('GET /:id');
  next();
}, userController.getUser);

router.put('/:id', (req, res, next) => {
  console.log('PUT /:id');
  next();
}, userController.updateUser);

router.delete('/:id', (req, res, next) => {
  console.log('DELETE /:id');
  next();
}, userController.deleteUser);


router.post(
  '/login',
  [
    check('email', 'Please include a valid email').isEmail(),
    check('password', 'Password is required').exists(),
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    userController.login(req, res);
  }
);

module.exports = router;