const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/authMiddleware');

// @route    GET api/users/me
// @desc     Get current user
// @access   Private
router.get('/me', authMiddleware, (req, res) => {
  res.send('User information');
});

module.exports = router;